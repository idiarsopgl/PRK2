ParkIRC Parking Management System - Windows Version

PERSYARATAN SISTEM:
- Windows 64-bit
- .NET 6.0 Runtime (jika tidak menggunakan self-contained version)
- Port 5126 dan 5127 tersedia
- Minimal RAM 4GB
- Ruang disk minimal 500MB

CARA PENGGUNAAN:
1. Extract semua file ke folder yang diinginkan
2. Jalankan "start.bat"
3. Browser akan terbuka otomatis ke http://localhost:5126
4. Login dengan kredensial default:
   Email: admin@parkingsystem.com
   Password: Admin@123

STRUKTUR FOLDER:
- ParkIRC.exe : Aplikasi utama
- start.bat : Script untuk menjalankan aplikasi
- appsettings.json : File konfigurasi
- GeexParking.db : Database SQLite
- logs/ : Folder untuk log aplikasi
- wwwroot/ : Folder untuk file statis

TROUBLESHOOTING:
1. Jika aplikasi tidak bisa dijalankan:
   - Pastikan port 5126 dan 5127 tidak digunakan aplikasi lain
   - Pastikan folder memiliki permission write
   - Cek file log di folder logs/

2. Jika browser tidak terbuka otomatis:
   - Buka browser manual dan akses http://localhost:5126

BANTUAN:
Jika mengalami masalah, silakan buat issue di:
https://github.com/idiarsopgl/PRK2/issues 