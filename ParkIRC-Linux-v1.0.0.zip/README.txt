ParkIRC Parking Management System - Linux Version

PERSYARATAN SISTEM:
- Linux 64-bit (Direkomendasikan: Pop!_OS atau Ubuntu)
- .NET 6.0 Runtime (jika tidak menggunakan self-contained version)
- Port 5126 dan 5127 tersedia
- Minimal RAM 4GB
- Ruang disk minimal 500MB

INSTALASI DEPENDENSI (jika tidak menggunakan self-contained version):
1. Install .NET Runtime:
   ```
   wget https://packages.microsoft.com/config/ubuntu/20.04/packages-microsoft-prod.deb -O packages-microsoft-prod.deb
   sudo dpkg -i packages-microsoft-prod.deb
   sudo apt update
   sudo apt install -y apt-transport-https
   sudo apt install -y dotnet-runtime-6.0
   ```

CARA PENGGUNAAN:
1. Extract semua file ke folder yang diinginkan
2. Buka terminal di folder tersebut
3. Buat script start.sh executable:
   ```
   chmod +x start.sh
   ```
4. Jalankan aplikasi:
   ```
   ./start.sh
   ```
5. Browser akan terbuka otomatis ke http://localhost:5126
6. Login dengan kredensial default:
   Email: admin@parkingsystem.com
   Password: Admin@123

STRUKTUR FOLDER:
- ParkIRC : Aplikasi utama
- start.sh : Script untuk menjalankan aplikasi
- appsettings.json : File konfigurasi
- GeexParking.db : Database SQLite
- logs/ : Folder untuk log aplikasi
- wwwroot/ : Folder untuk file statis

TROUBLESHOOTING:
1. Jika aplikasi tidak bisa dijalankan:
   - Pastikan file ParkIRC memiliki permission executable:
     ```
     chmod +x ParkIRC
     ```
   - Pastikan port 5126 dan 5127 tidak digunakan:
     ```
     sudo lsof -i :5126
     sudo lsof -i :5127
     ```
   - Pastikan folder memiliki permission write:
     ```
     chmod -R 755 .
     ```
   - Cek file log di folder logs/

2. Jika browser tidak terbuka otomatis:
   - Buka browser manual dan akses http://localhost:5126

BANTUAN:
Jika mengalami masalah, silakan buat issue di:
https://github.com/idiarsopgl/PRK2/issues 