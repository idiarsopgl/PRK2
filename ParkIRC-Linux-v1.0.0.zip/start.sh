#!/bin/bash

# Make the application executable
chmod +x ParkIRC

# Create logs directory if it doesn't exist
mkdir -p logs

# Start the application
./ParkIRC

# Open browser
xdg-open http://localhost:5126 